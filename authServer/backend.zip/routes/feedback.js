const express = require('express')
const mongoose = require('mongoose')
const jwt = require('jsonwebtoken')
const {jwtkey} = require('../keys')
const router = express.Router();
const User = mongoose.model('User');
const assert = require('assert');
require("mongoose-type-email");
const bcrypt = require('bcrypt');
const saltRounds = 10;

router.post("/feedback" , (req , res , next) => {
	const key = req.body.key;
	const username = req.body.name;
	const date = req.body.date;
	const comments = req.body.comments;
	const rating = req.body.rating;
	const edit = req.body.edit;//1 for insert, 2 for delete

	if(edit === 1)
	{
		//insert
		var newFeedback = new Feedback({
			_id : key,
			userName : username,
			date : date,
			comments : comments,
			rating : rating
		});

		newFeedback.save((err) => {
			if(!err)
			{
				res.send(JSON.stringify({
					success : true,
					message : "Feedback accepted! Thanks for your valuable feedback!"
				}));
			}
			else
			{
				res.send(JSON.stringify({
					success : false,
					message : "Failed to accept feedback! Try again! Sorry for the inconvinience!"
				}));
			}
		});
	}
	else
	{
		Feedback.deleteOne({"key" : key} , (err) => {
			if(!err)
                        {
                                res.send(JSON.stringify({
                                        success : true,
                                        message : "Feedback deleted!"
                                }));
                        }
                        else
                        {
                                res.send(JSON.stringify({
                                        success : false,
                                        message : "Failed to delete feedback! Try again! Sorry for the inconvinience!"
                                }));
                        }
		});
	}
});
module.exports = router;